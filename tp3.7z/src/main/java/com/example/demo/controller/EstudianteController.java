
package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Estudiante;
import com.example.demo.repository.EstudianteRepository;

@RestController
@RequestMapping("estudiantes") // barra estudiantes barra

public class EstudianteController {

	@Qualifier("estudianteRepository") // permite especificar el nombre del bean(componente) que se va a inyectar en el
										// atributo
	@Autowired // realiza la inyección de dependencias y no es necesario instanciarla

	private EstudianteRepository repository;

	// constructor
	public EstudianteController(@Qualifier("estudianteRepository") EstudianteRepository estudiante) {
		this.repository = estudiante;
	}
	
	@GetMapping("/")
	public Iterable<Estudiante> getEstudiantes() {
		return repository.findAll();
	}

	// A) dar de alta un estudiante

	@PostMapping(value="/agregarEstudiante/", headers = "content-type=application/json")
	public Estudiante nuevoEstudiante(@RequestBody Estudiante estudiante) {
		return repository.save(estudiante);
	}

	// c) recuperar todos los estudiantes, y especificar algún criterio de
	// ordenamiento simple.

	@GetMapping("/estudiantesOrdenados/")
	public List<Estudiante> buscarEstudiantesOrdenadosPorNombre() {
		return repository.buscarEstudiantesOrdenadosPorNombre();
	}
	
	@GetMapping("/nombre/{nombre}")
	public Iterable<Estudiante> obtenerEstudiantesPorNombreOrdenarPorApellido(@PathVariable String nombre) {
		return repository.findByNombreOrderByApellidoDesc(nombre);
	}
	
	
	//d) recuperar un estudiante, en base a su número de libreta universitaria.
	@GetMapping("/numerolibreta/{numLibreta}")
	public Estudiante obtenerEstudiantePorNumeroLibreta(@PathVariable int numLibreta) {
		return repository.findByNumLibreta(numLibreta);
	}
	
	//e) recuperar todos los estudiantes, en base a su género.
	@GetMapping("/genero/{genero}")
	public Iterable<Estudiante> obtenerEstudiantesPorGenero(@PathVariable boolean genero){
		return repository.findByGenero(genero);
	}

}
