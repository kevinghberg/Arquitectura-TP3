package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dtos.CarreraInscriptosDto;
import com.example.demo.model.Carrera_Estudiante;
import com.example.demo.repository.Carrera_Estudiante_Repository;

@RestController
@RequestMapping("relaciones")
public class Carrera_Estudiante_Controller {

	@Qualifier("Carrera_Estudiante_Repository")
	@Autowired
	private Carrera_Estudiante_Repository repository;

	public Carrera_Estudiante_Controller(
		@Qualifier("Carrera_Estudiante_Repository") Carrera_Estudiante_Repository relacion) {
		this.repository = relacion;
	}

	// b) matricular un estudiante en una carrera

	@PostMapping(value="/agregar/", headers = "content-type=application/json")
	public Carrera_Estudiante nuevoEstudiante(@RequestBody Carrera_Estudiante relacion) {
		return repository.save(relacion);
	}
	
	@GetMapping("/cantidadinscriptos/")
	public List<CarreraInscriptosDto> obtenerCarrerasCantidadInscriptos(){
		List<CarreraInscriptosDto> lista = repository.obtenerCarrerasCantidadInscriptos();
		return lista;
	}

}
