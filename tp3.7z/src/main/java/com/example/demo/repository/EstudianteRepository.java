package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Estudiante;

public interface EstudianteRepository  extends JpaRepository<Estudiante, Long> {
	
	@Query ("SELECT e FROM Estudiante e where e.nombre = :nombre")
	public List<Estudiante> buscarTodosPorNombre(String nombre);
	
	@Query ("SELECT e FROM Estudiante e ORDER BY e.nombre")
	public List<Estudiante> buscarEstudiantesOrdenadosPorNombre();
	
	public List<Estudiante> findByNombreOrderByApellidoDesc(String nombre);
	
	public Estudiante findByNumLibreta(int numLibreta);

	public Iterable<Estudiante> findByGenero(boolean genero);
}
