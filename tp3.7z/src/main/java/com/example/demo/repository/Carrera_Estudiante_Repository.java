package com.example.demo.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Carrera;
import com.example.demo.dtos.CarreraInscriptosDto;
import com.example.demo.model.Carrera_Estudiante;
import com.example.demo.model.Estudiante;

public interface Carrera_Estudiante_Repository extends JpaRepository<Carrera_Estudiante, Long> {
	
	@Query("SELECT c.nombre, COUNT(ce.estudiante) FROM Carrera c JOIN Carrera_Estudiante ce GROUP BY c.nombre")
	public List<CarreraInscriptosDto> obtenerCarrerasCantidadInscriptos();
	
}
