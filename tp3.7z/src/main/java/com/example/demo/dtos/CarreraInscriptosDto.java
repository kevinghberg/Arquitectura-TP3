package com.example.demo.dtos;

import javax.persistence.Entity;

import lombok.Data;

public class CarreraInscriptosDto {

	public String nombreCarrera;

	public long cantidadInscriptos;

	public CarreraInscriptosDto() {
		super();
	}

	public CarreraInscriptosDto(String nombreCarrera, long cantidadInscriptos) {
		super();
		this.nombreCarrera = nombreCarrera;
		this.cantidadInscriptos = cantidadInscriptos;
	}

	public String getNombreCarrera() {
		return nombreCarrera;
	}

	public void setNombreCarrera(String nombreCarrera) {
		this.nombreCarrera = nombreCarrera;
	}

	public long getCantidadInscriptos() {
		return cantidadInscriptos;
	}

	public void setCantidadInscriptos(long cantidadInscriptos) {
		this.cantidadInscriptos = cantidadInscriptos;
	}

}
